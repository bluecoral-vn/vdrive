import{c as r}from"./index-DH79SmZa.js";import{a as i,F as s}from"./file-DEXKU-Zb.js";/**
 * @license lucide-react v0.563.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const n=[["path",{d:"M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",key:"1oefj6"}],["path",{d:"M14 2v5a1 1 0 0 0 1 1h5",key:"wfsgrz"}],["circle",{cx:"10",cy:"12",r:"2",key:"737tya"}],["path",{d:"m20 17-1.296-1.296a2.41 2.41 0 0 0-3.408 0L9 22",key:"wt3hpn"}]],c=r("file-image",n);/**
 * @license lucide-react v0.563.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const h=[["path",{d:"M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",key:"1oefj6"}],["path",{d:"M14 2v5a1 1 0 0 0 1 1h5",key:"wfsgrz"}],["path",{d:"M10 9H8",key:"b1mrlr"}],["path",{d:"M16 13H8",key:"t4e002"}],["path",{d:"M16 17H8",key:"z1uh3a"}]],f=r("file-text",h);function d(a){if(a===0)return"0 B";const t=1024,o=["B","KB","MB","GB"],e=Math.floor(Math.log(a)/Math.log(t));return`${parseFloat((a/Math.pow(t,e)).toFixed(1))} ${o[e]}`}function M(a){return a.startsWith("image/")?c:a.startsWith("video/")?i:a.startsWith("text/")?f:s}const u="application/x-drive-item";function y(a){const t=JSON.parse(a);return Array.isArray(t)?t:[t]}export{u as D,f as F,c as a,d as f,M as g,y as p};
