import{c}from"./index-DjjYJCw0.js";/**
 * @license lucide-react v0.563.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const l=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20",key:"13o1zl"}],["path",{d:"M2 12h20",key:"9i4pu4"}]],u=c("globe",l),f=[{value:"none",label:"No expiration"},{value:"1d",label:"1 day"},{value:"7d",label:"7 days"},{value:"30d",label:"30 days"},{value:"90d",label:"90 days"}],s={none:0,"1d":1,"7d":7,"30d":30,"90d":90};function y(e){if(e==="none")return null;const n=s[e],t=new Date;return t.setDate(t.getDate()+n),t.toISOString()}function p(e){if(!e)return"none";const n=new Date(e),t=new Date,o=n.getTime()-t.getTime();if(o<=0)return"none";const r=o/(1e3*60*60*24),d=.5;for(const a of["1d","7d","30d","90d"])if(Math.abs(r-s[a])<d)return a;return"none"}export{f as E,u as G,p as e,y as p};
