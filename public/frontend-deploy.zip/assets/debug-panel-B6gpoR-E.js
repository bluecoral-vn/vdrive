import{r,j as e}from"./vendor-router-Cc4DNRLo.js";import{c as n,B as m,K as c}from"./index-gGspu-24.js";import{C as i}from"./chevron-down-4UpQu0XG.js";/**
 * @license lucide-react v0.563.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const p=[["path",{d:"m16 18 6-6-6-6",key:"eg8j8"}],["path",{d:"m8 6-6 6 6 6",key:"ppft3o"}]],d=n("code",p);function f({data:t,label:o="Raw JSON Response"}){const[s,a]=r.useState(!1);return e.jsxs("div",{className:"mt-4 border-t pt-4",children:[e.jsxs(m,{variant:"ghost",size:"sm",onClick:()=>a(!s),className:"gap-2 text-muted-foreground",children:[e.jsx(d,{className:"size-4"}),o,s?e.jsx(c,{className:"size-3"}):e.jsx(i,{className:"size-3"})]}),s&&e.jsx("pre",{className:"mt-2 max-h-96 overflow-auto rounded-md bg-muted p-4 text-xs",children:JSON.stringify(t,null,2)})]})}export{f as D};
