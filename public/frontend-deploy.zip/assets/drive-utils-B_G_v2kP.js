import{c as e}from"./index-BDeD6Owh.js";import{F as i}from"./file-play-DLmAe_Uj.js";import{F as s}from"./file-text-BNHNT7vv.js";import{F as n}from"./file-BNCPENXN.js";/**
 * @license lucide-react v0.563.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const c=[["path",{d:"M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",key:"1oefj6"}],["path",{d:"M14 2v5a1 1 0 0 0 1 1h5",key:"wfsgrz"}],["circle",{cx:"10",cy:"12",r:"2",key:"737tya"}],["path",{d:"m20 17-1.296-1.296a2.41 2.41 0 0 0-3.408 0L9 22",key:"wt3hpn"}]],f=e("file-image",c);function F(t){if(t===0)return"0 B";const a=1024,o=["B","KB","MB","GB"],r=Math.floor(Math.log(t)/Math.log(a));return`${parseFloat((t/Math.pow(a,r)).toFixed(1))} ${o[r]}`}function d(t){return t.startsWith("image/")?f:t.startsWith("video/")?i:t.startsWith("text/")?s:n}const m="application/x-drive-item";function g(t){const a=JSON.parse(t);return Array.isArray(a)?a:[a]}export{m as D,f as F,F as f,d as g,g as p};
